package main

import (
	"fmt"
	"net/http"
	"strings"
	"github.com/strata-io/service-extension/orchestrator"
	"github.com/strata-io/service-extension/idfabric"
)

// IsAuthenticated determines if the user is authenticated. Authentication status is
// derived by querying the session cache.
func IsAuthenticated(api orchestrator.Orchestrator, rw http.ResponseWriter, _ *http.Request) bool {
	logger := api.Logger()
	logger.Info("se", "determining if user is authenticated or not")
    
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
		return false
	}
    
    authenticationIDP, err := session.GetString("authenticationIdp")
	authenticated, err := session.GetString(authenticationIDP + ".authenticated")
	
	if err != nil {
		logger.Error(
			"se", fmt.Sprintf("unable to retrieve session value '%s.authenticated'", authenticationIDP),
			"error", err.Error(),
		)
	}
	if authenticated == "true" {
		logger.Info("se", fmt.Sprintf("user is authenticated with '%s'", authenticationIDP))
		email, err := session.GetString(authenticationIDP + ".email")
    	if err != nil {
    	    logger.Error(
			"se", fmt.Sprintf("unable to retrieve session value '%s.email'", authenticationIDP),
			"error", err.Error(),
		    )
    	}
    	session.SetString("GlobalLandingPage.email", email)
    	err = session.Save()
    	if err != nil {
    	    logger.Error(
			"se", fmt.Sprintf("unable to save session state", authenticationIDP),
			"error", err.Error(),
		    )
    	}
        return true
	}
    logger.Info("not authenticated yet")
	return false
}

// Authenticate authenticates the user against the IDP that they select.
func Authenticate(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Info("se", "authenticating user")

	if req.Method == http.MethodGet {
		logger.Info("se", "received GET request, rendering login form html page")
		// ServiceExtensionAssets exposes any assets that may have been bundled with the
        // service extension.
        assets := api.ServiceExtensionAssets()
        // ReadFile returns the file contents as a []byte.
        idpForm, err := assets.ReadFile("index.html")
        if err != nil {
            logger.Error("se", "failed to read service extension asset file", "error", err.Error())
            http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
            return
        }
        _, _ = rw.Write(idpForm)
		return
	}

	if req.Method != http.MethodPost {
		logger.Error("se", fmt.Sprintf("received unexpected request method '%s', expected POST", req.Method))
		http.Error(rw, http.StatusText(http.StatusBadRequest), http.StatusBadRequest)
		return
	}

	logger.Debug("se", "parsing form from request")
	err := req.ParseForm()
	if err != nil {
		logger.Error("se", "failed to parse form from request", "error", err.Error())
		http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
		return
	}

	email := req.Form.Get("username")
	domain := strings.Split(email, "@")[1]
	logger.Info("se", fmt.Sprintf("User with domain '%s' is attempting to authenticate", domain))
	
	// Here you would determine the IDP based on the domain
	// For example, you could have a map or a switch statement
	// idpDomainMap maps email domains to IDP identifiers
    var idpDomainMap = map[string]string{
    "M365x75558759.onmicrosoft.com": "EntraIDDemoTenant",
//	"pingonetrial.com": "PingOneCIAMTrial",
//	"oktatrial.com": "OktaIDPTest",
    }
	// Add more domain-to-IDP mappings here
	
    // Check if the domain exists in the idpDomainMap
	authenticationIDP, ok := idpDomainMap[domain]
	session, err := api.Session()
    session.SetString("authenticationIdp", authenticationIDP)
	session.SetString("user_email", email)
	err = session.Save()
    if err != nil {
        logger.Error("se", fmt.Sprintf("unable to save session value '%s'", authenticationIDP), "error", err.Error())
    }
	logger.Info("se", fmt.Sprintf("user is prompted to '%s' IDP for authentication", authenticationIDP))
	if !ok {
		logger.Error("se", "no IDP found for domain", "domain", domain)
		http.Error(rw, "No IDP found for the provided domain", http.StatusBadRequest)
		return
	}

	idp, err := api.IdentityProvider(authenticationIDP)
	
	if err != nil {
		logger.Error("se", "unable to lookup idp", "error", err.Error())
		http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
		return
	}
	
	//idp.Login(rw, req)
    loginHintOption := idfabric.WithLoginHint(email)
    idp.Login(rw, req, loginHintOption)
	return
}