package main

import (
	"fmt"
	"html/template"
	"net/http"
	"strings"

	"github.com/strata-io/service-extension/orchestrator"
)

type ErrorState int

const (
	ErrorUnknown ErrorState = iota
	ErrorInvalidCitizenship
	ErrorNoIdPFound
	ErrorInvalidBemsid
	ErrorInvalidGeolocation
	Error1Kosmos
)

type ErrorData struct {
	Message     string
	Code        uint
	CodeMessage string
}

type IDP struct {
	Name  string
	Value string
}

// IsAuthenticated determines if the user is authenticated. Authentication status is
// derived by querying the session cache.
func IsAuthenticated(api orchestrator.Orchestrator, rw http.ResponseWriter, _ *http.Request) bool {
	logger := api.Logger()
	logger.Info("se", "determining if user is authenticated or not")

	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
		return false
	}

	authenticationIDP, err := session.GetString("authenticationIdp")
	authenticated, err := session.GetBool(authenticationIDP + ".authenticated")

	if err != nil {
		logger.Error(
			"se", fmt.Sprintf("unable to retrieve session value '%s.authenticated'", authenticationIDP),
			"error", err.Error(),
		)
		return false
	}
	if authenticated {
		logger.Info("se", fmt.Sprintf("user is authenticated with '%s'", authenticationIDP))
		email, err := session.GetString(authenticationIDP + ".email")
		if err != nil {
			logger.Error(
				"se", fmt.Sprintf("unable to retrieve session value '%s.email'", authenticationIDP),
				"error", err.Error(),
			)
			return false
		}
		session.SetString("GlobalLandingPage.email", email)
		err = session.Save()
		if err != nil {
			logger.Error(
				"se", fmt.Sprintf("unable to save session state: %v", authenticationIDP),
				"error", err.Error(),
			)
			return false
		}
		return true
	}
	logger.Info("not authenticated yet")
	return false
}

// Authenticate authenticates the user against the IDP that they select.
func Authenticate(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	idpDomains := []IDP{
		{
			"EntraoIDDemoTenant",
			"M365x75558759.onmicrosoft.com",
		},
		{
			"PenguinztliveTenant",
			"penguinztlive.onmicrosoft.com",
		},
	}
	// DEBUG flag used for testing
	DEBUG := true

	logger := api.Logger()

	if req.Method == http.MethodGet {

		// DEBUG SECTION
		if DEBUG {

			// Error State map for testing
			errorStateMap := map[string]ErrorState{
				"unknown":            ErrorUnknown,
				"noprovider":         ErrorNoIdPFound,
				"1kosmos":            Error1Kosmos,
				"invalidgeo":         ErrorInvalidGeolocation,
				"invalidbemsid":      ErrorInvalidBemsid,
				"invalidcitizenship": ErrorInvalidCitizenship,
			}

			// go to /errors/<map_value> to see the given error type's page layout
			if strings.Contains(req.URL.Path, "errors") {
				errorStateString, _ := strings.CutPrefix(req.URL.Path, "/errors/")
				errorState, ok := errorStateMap[errorStateString]
				if !ok {
					serve_error(api, rw, ErrorUnknown)
				} else {
					serve_error(api, rw, errorState)
				}
				return
			}
		}
		// END DEBUG SECTION

		if strings.Contains(req.URL.Path, "htmx.min.js") {
			err := serve_js(api, rw)
			if nil != err {
				logger.Error("se", "Failed to serve JS file", "error", err.Error())
				// page can still load if this error occurs
				http.Error(rw, "Internal Error, Please Contact System Admin.", http.StatusInternalServerError)
			}
			return
		}

		if strings.Contains(req.URL.Path, "style.css") {
			err := serve_css(api, rw)
			if nil != err {
				logger.Error("se", "Failed to serve CSS file", "error", err.Error())
				// page can still load if this error occurs
				http.Error(rw, "Internal Error, Please Contact System Admin.", http.StatusInternalServerError)
			}
			return
		}
		if strings.Contains(req.URL.Path, "images") {
			filename, _ := strings.CutPrefix(req.URL.Path, "/images/")
			err := serve_image(api, rw, filename)
			if nil != err {
				logger.Error("se", "failed to get image", "error", err.Error())
				// page can still load if this error occurs
				http.Error(rw, "Internal Error, Please Contact System Admin.", http.StatusInternalServerError)
			}
			return
		}

		// no path matched before...display index page
		err := serve_index(api, rw, idpDomains)
		if nil != err {
			logger.Error("se", "failed to get assets fs", "error", err.Error())
			serve_error(api, rw, ErrorUnknown)
		}
		return
	}

	if req.Method != http.MethodPost {
		logger.Error("se", fmt.Sprintf("received unexpected request method '%s', expected POST", req.Method))
		serve_error(api, rw, ErrorUnknown)
		return
	}

	// http.MethodPost from here to end of Authenticate
	logger.Info("se", "authenticating user")
	// get the User from the request

	// Get IDP from Form
	authenticationIDP := req.Form.Get("idp")
	session, err := api.Session()
	if nil != err {
		logger.Error("se", "unable to get api session", "error", err.Error())
		serve_error(api, rw, ErrorUnknown)
		return
	}
	err = session.SetString("authenticationIdp", authenticationIDP)
	if nil != err {
		logger.Error("se", "unable to save data to session", "error", err.Error())
		serve_error(api, rw, ErrorUnknown)
		return
	}

	logger.Info("se", fmt.Sprintf("Session=%+v", session))
	err = session.Save()
	if nil != err {
		logger.Error("se", "unable to save api session", "error", err.Error())
		serve_error(api, rw, ErrorUnknown)
		return
	}

	idp, err := api.IdentityProvider(authenticationIDP)
	logger.Info("se", fmt.Sprintf("Session=%+v", session))
	if nil != err {
		logger.Error("se", "Unable to get IdentityProvider object", "error", err.Error())
		serve_error(api, rw, ErrorUnknown)
		return
	}
	idp.Login(rw, req)
	return
}

func serve_index(api orchestrator.Orchestrator, rw http.ResponseWriter, idpDomains []IDP) error {
	assetFS, err := api.ServiceExtensionAssets().FS()
	if nil != err {
		return err
	}
	indextmpl, err := template.ParseFS(assetFS, "index.html")
	err = indextmpl.Execute(rw, idpDomains)
	return nil
}

func serve_image(api orchestrator.Orchestrator, w http.ResponseWriter, filename string) error {
	data, err := api.ServiceExtensionAssets().ReadFile(filename)
	filename_type_slice := strings.Split(filename, ".")
	filetype := filename_type_slice[len(filename_type_slice)-1]
	if nil != err {
		return err
	}
	w.Header().Set("Content-Type", "image/"+filetype)
	w.Write(data)
	return nil
}

func serve_css(api orchestrator.Orchestrator, w http.ResponseWriter) error {
	data, err := api.ServiceExtensionAssets().ReadFile("style.css")
	if nil != err {
		return err
	}
	w.Header().Set("Content-Type", "text/css")
	w.Write(data)
	return nil
}

func serve_error(api orchestrator.Orchestrator, w http.ResponseWriter, es ErrorState) error {
	assetFS, err := api.ServiceExtensionAssets().FS()
	if nil != err {
		return err
	}
	errtmpl, err := template.ParseFS(assetFS, "error.html")
	if nil != err {
		return err
	}
	errorData := generateErrorData(es)
	err = errtmpl.Execute(w, errorData)
	if nil != err {
		return err
	}
	return nil
}

func generateErrorData(es ErrorState) ErrorData {
	error_strings := map[ErrorState]string{
		ErrorUnknown:            "Looks like an error occured. Please contact helpdesk by phone or the link below for further assistance.",
		ErrorInvalidCitizenship: "Looks like you are accessing a resource only available to US citizens. If you think you have recieved this message in error please contact Helpdesk by phone or the link below.",
		ErrorNoIdPFound:         "Looks like we are unable to find the email domain you have entered. Please contact Helpdesk by phone or the link below.",
		ErrorInvalidBemsid:      "Looks like your BEMSID does not match what we have on file. Please contact Helpdesk by phone or the link below for assistance in logging in.",
		ErrorInvalidGeolocation: "Looks like you are trying to access a resource outside the USA. This resource is only available to users who currently reside on US soil.",
		Error1Kosmos:            "Error in Login from 1Kosmos. Please contact Helpdesk by phone or the link below for assistance logging in.",
	}

	error_codes := map[ErrorState]uint{
		ErrorUnknown:            http.StatusInternalServerError,
		ErrorInvalidCitizenship: http.StatusUnauthorized,
		ErrorNoIdPFound:         http.StatusBadRequest,
		ErrorInvalidBemsid:      http.StatusBadRequest,
		ErrorInvalidGeolocation: http.StatusUnauthorized,
		Error1Kosmos:            http.StatusBadRequest,
	}

	return ErrorData{
		error_strings[es],
		error_codes[es],
		http.StatusText(int(error_codes[es])),
	}
}
