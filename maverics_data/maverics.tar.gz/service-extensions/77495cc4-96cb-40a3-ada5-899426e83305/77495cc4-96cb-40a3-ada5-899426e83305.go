package main

import (
	"net/http"

	"github.com/strata-io/service-extension/orchestrator"
)

func ModifyResponse(api orchestrator.Orchestrator, resp *http.Response) {
	// Set CORS headers for all responses
	api.Logger().Debug("se", "setting CORS headers for all resources")
	resp.Header.Set("Access-Control-Allow-Origin", "https://ey.com, https://boeing.com, https://digitalaviationservices.com")
	resp.Header.Set("Access-Control-Allow-Credentials", "true")
	resp.Header.Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
	resp.Header.Set("Access-Control-Allow-Headers", "Content-Type, Authorization, Accept, Overwrite, Destination, Depth, User-Agent, Translate, Range, Content-Range, Timeout, X-File-Size, X-Requested-With, If-Modified-Since, X-File-Name, Cache-Control, Location, Lock-Token, If, app_name, x-signalr-user-agent")
	resp.Header.Set("Access-Control-Max-Age", "600")

    // If you want to ensure that you are appending to the existing headers rather than replacing them, you can modify the CORS header setting using resp.Header.Add //

	// Handle preflight requests
	if resp.Request.Method == http.MethodOptions {
		resp.StatusCode = http.StatusNoContent
		
	// Set Cache-Control header for OPTIONS requests
		resp.Header.Set("Cache-Control", "max-age=600")
		return
	}
}
