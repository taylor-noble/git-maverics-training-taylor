package main

import (
	"fmt"
	"net/http"
    ldap3 "github.com/go-ldap/ldap/v3"
	"github.com/strata-io/service-extension/orchestrator"
	"strings"
)

func CreateHeader(api orchestrator.Orchestrator, rw http.ResponseWriter, _ *http.Request) (http.Header, error) {
	logger := api.Logger()
	logger.Debug("se", "building custom header")
	
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		return nil, err
	}
	
	email, err := session.GetString("EntraIDDemoTenant.email")
	if err != nil {
		logger.Error("se", fmt.Sprintf("Unable to retrieve session value '%s'", email), "error", err.Error())
	}
	
	result, err := getUserAccountFromAD(api, email, rw)
	if err != nil {
	    logger.Error("se", "Error occurred during IDP value retrieval from LDAP", "error", err.Error())
	}
	logger.Info("se", fmt.Sprintf("User account retrieved from AD and status: '%s'", result))
	
	otherMobileSE, err := session.GetString("otherMobileSE")
	if err != nil {
		return nil, fmt.Errorf("unable to retrieve attribute 'otherMobileSE': %w", err)
	}
	
	// If all ok make the custom header and return to the Orchestrator.
	header := make(http.Header)
	
	header["dummy_spAttrs"] = []string{otherMobileSE}

	return header, nil
}

// getUserAccountFromAD retrieves attributes from the LDAPS provider.
func getUserAccountFromAD(api orchestrator.Orchestrator, email string, rw http.ResponseWriter) (string, error) {
	logger := api.Logger()
	secretProvider, err := api.SecretProvider()
	if err != nil {
		logger.Error("se", "Unable to get secret provider", "error", err.Error())
		return "", err
	}

	ldapsURL := "ldap://ldap.testad.com"
	l, err := ldap3.DialURL(ldapsURL)
	if err != nil {
		logger.Error("se", "Failed to connect to LDAPS server", "error", err.Error())
		return "", err
	}
	defer l.Close()
	
	serviceAccountUsername := secretProvider.GetString("serviceAccountUsername")
	serviceAccountPassword := secretProvider.GetString("serviceAccountPassword")
	if err := l.Bind(serviceAccountUsername, serviceAccountPassword); err != nil {
		logger.Error("se", "Failed to bind to LDAPS server", "error", err.Error())
		return "", err
	}
    
    //Define the uid variable
    uid:= "John.Doe"

	searchRequest := ldap3.NewSearchRequest(
		"OU=Users,OU=Accounts,DC=testad,DC=com",
		ldap3.ScopeWholeSubtree, ldap3.NeverDerefAliases, 0, 0, false,
		fmt.Sprintf("(&(objectClass=user)(sAMAccountName=%s))", uid),
		[]string{"mail", "cn", "otherMobile", "displayName", "info", "mail", "sAMAccountName", "employeeID", "employeeNumber", "department", "LDAPAttribute8", "LDAPAttribute9", "LDAPAttribute10", "LDAPAttribute11"},
		nil,
	)

	searchResult, err := l.Search(searchRequest)
	if err != nil {
		logger.Error("se", "Failed to search LDAPS", "error", err.Error())
		return "", err
	}
	logger.Info("se", fmt.Sprintf("LDAP search result count:%s", len(searchResult.Entries)))
	if len(searchResult.Entries) == 0 {
		logger.Error("se", "No user found with email", "error", email)
		return "", fmt.Errorf("no user found with email: %s", email)
	}

	if len(searchResult.Entries) == 1 {
		session, err := api.Session()
		otherMobileSE := searchResult.Entries[0].GetAttributeValues("otherMobile")

    // Log the raw data
    logger.Info("se", fmt.Sprintf("Raw otherMobileSE data: %v", otherMobileSE))

    // Transform AD attribute to <Resource>?-<Role1>-<Role2>-<Role3>;
    var resourceMap = make(map[string][]string)
    for _, part := range otherMobileSE {
        logger.Info("se", fmt.Sprintf("Processing part: %s", part))
        subParts := strings.Fields(part)
        if len(subParts) != 2 {
            logger.Error("se", "Invalid input format", "part", part)
            fmt.Println("Invalid input format")
            return "", fmt.Errorf("some error")
        }
        resource := subParts[0]
        role := subParts[1]
        resourceMap[resource] = append(resourceMap[resource], role)
    }
    
    // Build the transformed string
    var transformedParts []string
    for resource, roles := range resourceMap {
        transformed := fmt.Sprintf("%s?-", resource) + strings.Join(roles, "-")
        transformedParts = append(transformedParts, transformed)
    }
    
    // Join the transformed parts with a semicolon and add a hyphen and semicolon at the end
    otherMobileString := strings.Join(transformedParts, ";") + "-;"
    logger.Info("se", "Final transformed otherMobileString: %s", otherMobileString)
    
    // Retrieve additional LDAP attributes
    ldapAttributes := []string{
        fmt.Sprintf("SC=%s", searchResult.Entries[0].GetAttributeValue("LDAPAttribute1")),
        fmt.Sprintf("CT=%s", searchResult.Entries[0].GetAttributeValue("info")),
        fmt.Sprintf("UE=%s", searchResult.Entries[0].GetAttributeValue("mail")),
        fmt.Sprintf("SU=%s", searchResult.Entries[0].GetAttributeValue("LDAPAttribute5")),
        fmt.Sprintf("PB=%s", searchResult.Entries[0].GetAttributeValue("LDAPAttribute4")),
        fmt.Sprintf("PT=%s", searchResult.Entries[0].GetAttributeValue("department")),
        fmt.Sprintf("UP=%s", searchResult.Entries[0].GetAttributeValue("LDAPAttribute7")),
        fmt.Sprintf("DL=%s", searchResult.Entries[0].GetAttributeValue("LDAPAttribute8")),
        fmt.Sprintf("ID=%s", searchResult.Entries[0].GetAttributeValue("sAMAccountName")),
        fmt.Sprintf("BE=%s", searchResult.Entries[0].GetAttributeValue("employeeID")),
        fmt.Sprintf("AC=%s", searchResult.Entries[0].GetAttributeValue("LDAPAttribute11")),
    }
    
    // Join the additional attributes with a pipe separator
    additionalAttributesString := strings.Join(ldapAttributes, "|")
    
    // Combine both strings
    finalOutput := otherMobileString + additionalAttributesString
    logger.Info("se", "Final output: %s", finalOutput)
    
    session.SetString("otherMobileSE", finalOutput)
    err = session.Save()
    if err != nil {
        logger.Error("se", fmt.Sprintf("unable to save session value"), "error", err.Error())
    }
	}
	return "success", nil
}