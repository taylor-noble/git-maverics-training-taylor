package main

import (
	"net/http"

	"github.com/strata-io/service-extension/orchestrator"
)

// type ErrorState int
//
// const (
// 	ErrorUnknown ErrorState = iota
// 	ErrorInvalidCitizenship
// 	ErrorNoIdPFound
// 	ErrorInvalidBemsid
// 	ErrorInvalidGeolocation
// 	Error1Kosmos
// )
//
// type ErrorData struct {
// 	Message     string
// 	Code        uint
// 	CodeMessage string
// }

func CreateHeader(api orchestrator.Orchestrator, rw http.ResponseWriter, _ *http.Request) (http.Header, error) {
	// logger := api.Logger()
	// logger.Debug("se", "building custom header")
	//
	// session, err := api.Session()
	// if err != nil {
	// 	logger.Error("se", "unable to retrieve session", "error", err.Error())
	// 	return nil, err
	// }
	//
	// email, err := session.GetString("EntraIDDemoTenant.email")
	// if err != nil {
	// 	logger.Error("se", fmt.Sprintf("Unable to retrieve session value '%s'", email), "error", err.Error())
	// }
	//
	// result, err := getUserAccountFromAD(api, email, rw)
	// if err != nil {
	// 	logger.Error("se", "Error occurred during IDP value retrieval from LDAP", "error", err.Error())
	// }
	// logger.Info("se", fmt.Sprintf("User account retrieved from AD and status: '%s'", result))
	//
	// otherMobileSE, err := session.GetString("otherMobileSE")
	// if err != nil {
	// 	return nil, fmt.Errorf("unable to retrieve attribute 'otherMobileSE': %w", err)
	// }
	//
	// // If all ok make the custom header and return to the Orchestrator.
	header := make(http.Header)

	header["a_otherMobile_serviceextension"] = []string{"TestSTRING"}

	return header, nil
}

// getUserAccountFromAD retrieves attributes from the LDAPS provider.
// func getUserAccountFromAD(api orchestrator.Orchestrator, email string, rw http.ResponseWriter) (string, error) {
// 	logger := api.Logger()
// 	secretProvider, err := api.SecretProvider()
// 	if err != nil {
// 		logger.Error("se", "Unable to get secret provider", "error", err.Error())
// 		return "", err
// 	}
//
// 	ldapsURL := "ldap://ldap.stratademousers.com"
// 	l, err := ldap3.DialURL(ldapsURL)
// 	if err != nil {
// 		logger.Error("se", "Failed to connect to LDAPS server", "error", err.Error())
// 		return "", err
// 	}
// 	defer l.Close()
//
// 	serviceAccountUsername := secretProvider.GetString("serviceAccountUsername")
// 	serviceAccountPassword := secretProvider.GetString("serviceAccountPassword")
// 	if err := l.Bind(serviceAccountUsername, serviceAccountPassword); err != nil {
// 		logger.Error("se", "Failed to bind to LDAPS server", "error", err.Error())
// 		return "", err
// 	}
//
// 	searchRequest := ldap3.NewSearchRequest(
// 		"OU=Users,OU=Accounts,DC=testad,DC=com",
// 		ldap3.ScopeWholeSubtree, ldap3.NeverDerefAliases, 0, 0, false,
// 		fmt.Sprintf("(&(objectClass=user)(mail=%s))", email),
// 		[]string{"mail", "cn", "otherMobile", "LDAPAttribute1", "LDAPAttribute2", "LDAPAttribute3", "LDAPAttribute4", "LDAPAttribute5", "LDAPAttribute6", "LDAPAttribute7", "LDAPAttribute8", "LDAPAttribute9", "LDAPAttribute10", "LDAPAttribute11"},
// 		nil,
// 	)
//
// 	searchResult, err := l.Search(searchRequest)
// 	if err != nil {
// 		logger.Error("se", "Failed to search LDAPS", "error", err.Error())
// 		return "", err
// 	}
// 	logger.Info("se", fmt.Sprintf("LDAP search result count: %d", len(searchResult.Entries)))
// 	if len(searchResult.Entries) == 0 {
// 		logger.Error("se", "No user found with email", "error", email)
// 		return "", fmt.Errorf("no user found with email: %s", email)
// 	}
//
// 	if len(searchResult.Entries) == 1 {
// 		session, _ := api.Session()
//         GetLDAPClaims(searchResult.Entries[0], &session, logger)
// 	}
//
// 	// Handle multiple user accounts
// 	if len(searchResult.Entries) > 1 {
// 		logger.Info("se", "multiple accounts found: %s", len(searchResult.Entries))
// 		var userAccounts []UserAccount
// 		for _, entry := range searchResult.Entries {
// 			userAccounts = append(userAccounts, UserAccount{
// 				DN:             entry.DN,
// 				CN:             entry.GetAttributeValue("cn"),
// 				Mail:           entry.GetAttributeValue("mail"),
// 				SamAccountName: entry.GetAttributeValue("sAMAccountName"),
// 			})
// 		}
//
// 		// Render the selection page with a modal
// 		assetFS, _ := api.ServiceExtensionAssets().FS()
// 		tmpl, _ := template.ParseFS(assetFS, "account_select.html")
// 		tmpl.Execute(rw, struct{ UserAccounts []UserAccount }{UserAccounts: userAccounts})
// 		return "", nil
// 	}
//
// 	return "success", nil
// }
//
// type UserAccount struct {
// 	DN             string
// 	CN             string
// 	Mail           string
// 	SamAccountName string
// }
//
// func GetLDAPClaims(ldapEntry *ldap3.Entry, session *session.Provider, logger log.Logger) (string, error) {
// 	otherMobileSE := ldapEntry.GetAttributeValues("otherMobile")
// 	// Log the raw data
// 	logger.Info("se", fmt.Sprintf("Raw otherMobileSE data: %v", otherMobileSE))
//
// 	// Transform AD attribute to <Resource>?-<Role1>-<Role2>-<Role3>;
// 	var resourceMap = make(map[string][]string)
// 	for _, part := range otherMobileSE {
// 		logger.Info("se", fmt.Sprintf("Processing part: %s", part))
// 		subParts := strings.Fields(part)
// 		if len(subParts) != 2 {
// 			logger.Error("se", "Invalid input format", "part", part)
// 			fmt.Println("Invalid input format")
// 			return "", fmt.Errorf("some error")
// 		}
// 		resource := subParts[0]
// 		role := subParts[1]
// 		resourceMap[resource] = append(resourceMap[resource], role)
// 	}
//
// 	// Build the transformed string
// 	var transformedParts []string
// 	for resource, roles := range resourceMap {
// 		transformed := fmt.Sprintf("%s?-", resource) + strings.Join(roles, "-")
// 		transformedParts = append(transformedParts, transformed)
// 	}
//
// 	// Join the transformed parts with a semicolon and add a semicolon at the end
// 	otherMobileString := strings.Join(transformedParts, ";") + ";"
// 	logger.Info("se", "Final transformed otherMobileString: %s", otherMobileString)
//
// 	// Retrieve additional LDAP attributes
// 	ldapAttributes := []string{
// 		fmt.Sprintf("SC=%s", ldapEntry.GetAttributeValue("LDAPAttribute1")),
// 		fmt.Sprintf("CT=%s", ldapEntry.GetAttributeValue("LDAPAttribute2")),
// 		fmt.Sprintf("UE=%s", ldapEntry.GetAttributeValue("LDAPAttribute3")),
// 		fmt.Sprintf("SU=%s", ldapEntry.GetAttributeValue("LDAPAttribute5")),
// 		fmt.Sprintf("PB=%s", ldapEntry.GetAttributeValue("LDAPAttribute4")),
// 		fmt.Sprintf("PT=%s", ldapEntry.GetAttributeValue("LDAPAttribute6")),
// 		fmt.Sprintf("UP=%s", ldapEntry.GetAttributeValue("LDAPAttribute7")),
// 		fmt.Sprintf("DL=%s", ldapEntry.GetAttributeValue("LDAPAttribute8")),
// 		fmt.Sprintf("ID=%s", ldapEntry.GetAttributeValue("LDAPAttribute9")),
// 		fmt.Sprintf("BE=%s", ldapEntry.GetAttributeValue("LDAPAttribute10")),
// 		fmt.Sprintf("AC=%s", ldapEntry.GetAttributeValue("LDAPAttribute11")),
// 	}
//
// 	// Join the additional attributes with a pipe separator
// 	additionalAttributesString := strings.Join(ldapAttributes, "|")
//
// 	// Combine both strings
// 	finalOutput := otherMobileString + additionalAttributesString
// 	logger.Info("se", "Final output: %s", finalOutput)
//
// 	(*session).SetString("otherMobileSE", finalOutput)
//     err := (*session).Save()
// 	if err != nil {
// 		logger.Error("se", fmt.Sprintf("unable to save session value"), "error", err.Error())
// 	}
//     return "", nil
// }
