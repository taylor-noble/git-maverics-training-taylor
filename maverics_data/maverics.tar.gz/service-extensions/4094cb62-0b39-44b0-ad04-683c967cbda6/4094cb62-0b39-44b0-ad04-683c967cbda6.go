package main

import (
	"fmt"
	"html/template"
	"net/http"
	"strings"

	"github.com/strata-io/service-extension/idfabric"
	"github.com/strata-io/service-extension/log"
	"github.com/strata-io/service-extension/orchestrator"
)

type ErrorState int

const (
	ErrorUnknown ErrorState = iota
	ErrorInvalidCitizenship
	ErrorNoIdPFound
	ErrorInvalidBemsid
	ErrorInvalidGeolocation
	Error1Kosmos
)

type ErrorData struct {
	Message     string
	Code        uint
	CodeMessage string
}

type User struct {
	Username string
	Domain   string
}

func (u User) GetEmail() string {
	return u.Username + "@" + u.Domain
}

// IsAuthenticated determines if the user is authenticated. Authentication status is
// derived by querying the session cache.
func IsAuthenticated(api orchestrator.Orchestrator, rw http.ResponseWriter, _ *http.Request) bool {
	logger := api.Logger()
	logger.Info("se", "determining if user is authenticated or not")

	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
		return false
	}

	authenticationIDP, err := session.GetString("authenticationIdp")
	authenticated, err := session.GetString(authenticationIDP + ".authenticated")

	if err != nil {
		logger.Error(
			"se", fmt.Sprintf("unable to retrieve session value '%s.authenticated'", authenticationIDP),
			"error", err.Error(),
		)
		return false
	}
	if authenticated == "true" {
		logger.Info("se", fmt.Sprintf("user is authenticated with '%s'", authenticationIDP))
		email, err := session.GetString(authenticationIDP + ".email")
		if err != nil {
			logger.Error(
				"se", fmt.Sprintf("unable to retrieve session value '%s.email'", authenticationIDP),
				"error", err.Error(),
			)
			return false
		}
		session.SetString("GlobalLandingPage.email", email)
		err = session.Save()
		if err != nil {
			logger.Error(
				"se", fmt.Sprintf("unable to save session state: %v", authenticationIDP),
				"error", err.Error(),
			)
			return false
		}
		return true
	}
	logger.Info("not authenticated yet")
	return false
}

// Authenticate authenticates the user against the IDP that they select.
func Authenticate(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	// DEBUG flag used for testing
	DEBUG := true

	logger := api.Logger()

	if req.Method == http.MethodGet {

		// DEBUG SECTION
		if DEBUG {

			// Error State map for testing
			errorStateMap := map[string]ErrorState{
				"unknown":            ErrorUnknown,
				"noprovider":         ErrorNoIdPFound,
				"1kosmos":            Error1Kosmos,
				"invalidgeo":         ErrorInvalidGeolocation,
				"invalidbemsid":      ErrorInvalidBemsid,
				"invalidcitizenship": ErrorInvalidCitizenship,
			}

            // go to /errors/<map_value> to see the given error type's page layout
			if strings.Contains(req.URL.Path, "errors") {
				errorStateString, _ := strings.CutPrefix(req.URL.Path, "/images/")
				errorState, ok := errorStateMap[errorStateString]
				if !ok {
					serve_error(api, rw, ErrorUnknown)
				} else {
					serve_error(api, rw, errorState)
				}
				return
			}
		}
		// END DEBUG SECTION

		if strings.Contains(req.URL.Path, "htmx.min.js") {
			err := serve_js(api, rw)
			if nil != err {
				logger.Error("se", "Failed to serve JS file", "error", err.Error())
				// page can still load if this error occurs
				http.Error(rw, "Internal Error, Please Contact System Admin.", http.StatusInternalServerError)
			}
			return
		}

		if strings.Contains(req.URL.Path, "style.css") {
			err := serve_css(api, rw)
			if nil != err {
				logger.Error("se", "Failed to serve CSS file", "error", err.Error())
				// page can still load if this error occurs
				http.Error(rw, "Internal Error, Please Contact System Admin.", http.StatusInternalServerError)
			}
			return
		}
		if strings.Contains(req.URL.Path, "images") {
			filename, _ := strings.CutPrefix(req.URL.Path, "/images/")
			err := serve_image(api, rw, filename)
			if nil != err {
				logger.Error("se", "failed to get image", "error", err.Error())
				// page can still load if this error occurs
				http.Error(rw, "Internal Error, Please Contact System Admin.", http.StatusInternalServerError)
			}
			return
		}
		if strings.Contains(req.URL.Path, "tabs") {
			filename, _ := strings.CutPrefix(req.URL.Path, "/tabs/")
			logger.Info("se", "Filename", "Name=", filename)
			err := serve_html(api, rw, filename, nil)
			if nil != err {
				logger.Error("se", "failed to get tab page", "error", err.Error())
				// page cannot load if this fails, show error page
				serve_error(api, rw, ErrorUnknown)
			}
			return
		}

		// no path matched before...display index page
		err := serve_index(api, rw)
		if nil != err {
			logger.Error("se", "failed to get assets fs", "error", err.Error())
			serve_error(api, rw, ErrorUnknown)
		}
		return
	}

	if req.Method != http.MethodPost {
		logger.Error("se", fmt.Sprintf("received unexpected request method '%s', expected POST", req.Method))
		serve_error(api, rw, ErrorUnknown)
		return
	}

	// http.MethodPost from here to end of Authenticate
	logger.Info("se", "authenticating user")
	// get the User from the request
	user, err := parse_form_request(req)

	if nil != err {
		logger.Error("se", "failed to parse form from request", "error", err.Error())
		http.Error(rw, http.StatusText(http.StatusBadRequest), http.StatusBadRequest)
		serve_error(api, rw, ErrorUnknown)
		return
	}

	// Here you would determine the IDP based on the domain
	// For example, you could have a map or a switch statement
	// idpDomainMap maps email domains to IDP identifiers
	logger.Info("se", fmt.Sprintf("Before getting IDP, User=%+v", user))
	authenticationIDP, err := get_idp_provider(user, logger)
	if err != nil {
		logger.Error("se", "unable to lookup idp", "error", err.Error())
		serve_error(api, rw, ErrorNoIdPFound)
		return
	}

	logger.Info("se", fmt.Sprintf("User Email=%s", user.GetEmail()))
	session, err := api.Session()
	if nil != err {
		logger.Error("se", "unable to get api session", "error", err.Error())
		serve_error(api, rw, ErrorUnknown)
		return
	}
	err = session.SetString("authenticationIdp", authenticationIDP)
	if nil != err {
		logger.Error("se", "unable to save data to session", "error", err.Error())
		serve_error(api, rw, ErrorUnknown)
		return
	}

	err = session.SetString("user_email", user.GetEmail())
	if nil != err {
		logger.Error("se", "unable to save data to session", "error", err.Error())
		serve_error(api, rw, ErrorUnknown)
		return
	}

	logger.Info("se", fmt.Sprintf("Session=%+v", session))
	err = session.Save()
	if nil != err {
		logger.Error("se", "unable to save api session", "error", err.Error())
		serve_error(api, rw, ErrorUnknown)
		return
	}

	idp, err := api.IdentityProvider(authenticationIDP)
	logger.Info("se", fmt.Sprintf("Session=%+v", session))
	logger.Info("se", fmt.Sprintf("Session=%+v", session))
	if nil != err {
		logger.Error("se", "Unable to get IdentityProvider object", "error", err.Error())
		serve_error(api, rw, ErrorUnknown)
		return
	}

	loginHintOption := idfabric.WithLoginHint(user.GetEmail())
	idp.Login(rw, req, loginHintOption)
	return
}

func serve_js(api orchestrator.Orchestrator, w http.ResponseWriter) error {
	data, err := api.ServiceExtensionAssets().ReadFile("htmx.min.js")
	if nil != err {
		return err
	}
	w.Header().Set("Content-Type", "text/javascript")
	w.Write(data)
	return nil
}

func get_idp_provider(user User, logger log.Logger) (string, error) {
	// Here you would determine the IDP based on the domain
	// For example, you could have a map or a switch statement
	// idpDomainMap maps email domains to IDP identifiers
	idpDomainMap := map[string]string{
		"M365x75558759.onmicrosoft.com": "EntraIDDemoTenant",
		"test.example.com":              "ExampleTenant",
	}
	// Add more domain-to-IDP mappings here
	//	"pingonetrial.com": "PingOneCIAMTrial",
	//	"oktatrial.com": "OktaIDPTest",

	// Check if the domain exists in the idpDomainMap
	authenticationIDP, ok := idpDomainMap[user.Domain]

	logger.Info("se", "Inside get_idp_provider",
		fmt.Sprintf("user=%+v, idpDomainMap=%+v", user, idpDomainMap),
		fmt.Sprintf("authenticationIDP=%q, ok=%t", authenticationIDP, ok))

	if !ok {
		return "", fmt.Errorf("No IdP Provider")
	}

	return authenticationIDP, nil
}

func parse_form_request(req *http.Request) (User, error) {
	err := req.ParseForm()
	if nil != err {
		return User{"", ""}, err
	}
	email := req.Form.Get("username")
	split := strings.Split(email, "@")
	return User{split[0], split[1]}, nil
}

func serve_index(api orchestrator.Orchestrator, rw http.ResponseWriter) error {
	assetFS, err := api.ServiceExtensionAssets().FS()
	if nil != err {
		return err
	}
	indextmpl, err := template.ParseFS(assetFS, "index.html")
	err = indextmpl.Execute(rw, nil)
	return nil
}

func serve_image(api orchestrator.Orchestrator, w http.ResponseWriter, filename string) error {
	data, err := api.ServiceExtensionAssets().ReadFile(filename)
	filename_type_slice := strings.Split(filename, ".")
	filetype := filename_type_slice[len(filename_type_slice)-1]
	if nil != err {
		return err
	}
	w.Header().Set("Content-Type", "image/"+filetype)
	w.Write(data)
	return nil
}

func serve_css(api orchestrator.Orchestrator, w http.ResponseWriter) error {
	data, err := api.ServiceExtensionAssets().ReadFile("style.css")
	if nil != err {
		return err
	}
	w.Header().Set("Content-Type", "text/css")
	w.Write(data)
	return nil
}

func serve_html(api orchestrator.Orchestrator, w http.ResponseWriter, filename string, data any) error {
	assetsFS, err := api.ServiceExtensionAssets().FS()
	tmpl, err := template.ParseFS(assetsFS, filename+".html")
	if nil != err {
		return err
	}
	w.Header().Set("Content-Type", "text/html")
	tmpl.Execute(w, data)
	return nil
}

func serve_error(api orchestrator.Orchestrator, w http.ResponseWriter, es ErrorState) error {
	assetFS, err := api.ServiceExtensionAssets().FS()
	if nil != err {
		return err
	}
	errtmpl, err := template.ParseFS(assetFS, "error.html")
	if nil != err {
		return err
	}
	err_code := generateErrorCode(es)
	err = errtmpl.Execute(w, ErrorData{
		generateErrorString(es),
		err_code,
		http.StatusText(int(err_code)),
	})
	if nil != err {
		return err
	}
	return nil
}

func generateErrorString(es ErrorState) string {
	error_strings := map[ErrorState]string{
		ErrorUnknown:            "Looks like an error occured. Please contact helpdesk by phone or the link below for further assistance.",
		ErrorInvalidCitizenship: "Looks like you are accessing a resource only available to US citizens. If you think you have recieved this message in erro, please contact Helpdesk by phone or the link below.",
		ErrorNoIdPFound:         "Looks like we are unable to find the email domain you have entered. Please contact Helpdesk by phone or the link below.",
		ErrorInvalidBemsid:      "Looks like your BEMSID does not match what we have on file. Please contact Helpdesk by phone or the link below for assistance in logging in.",
		ErrorInvalidGeolocation: "Looks like you are trying to access a resource outside the USA. This resource is only available to users who currently reside on US soil.",
		Error1Kosmos:            "Error in Login from 1Kosmos",
	}
	return error_strings[es]
}

func generateErrorCode(es ErrorState) uint {
	error_strings := map[ErrorState]uint{
		ErrorUnknown:            http.StatusInternalServerError,
		ErrorInvalidCitizenship: http.StatusUnauthorized,
		ErrorNoIdPFound:         http.StatusBadRequest,
		ErrorInvalidBemsid:      http.StatusBadRequest,
		ErrorInvalidGeolocation: http.StatusUnauthorized,
		Error1Kosmos:            http.StatusBadRequest,
	}
	return error_strings[es]
}
