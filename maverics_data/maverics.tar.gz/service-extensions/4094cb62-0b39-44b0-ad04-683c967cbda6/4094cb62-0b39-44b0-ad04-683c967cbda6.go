package main

import (
	"fmt"
	"github.com/strata-io/service-extension/idfabric"
	"github.com/strata-io/service-extension/orchestrator"
	"html/template"
	"net/http"
	"strings"
)

type ErrorData struct {
	Message string
	Code    int
}

type User interface {
    GetEmail() 
    GetDomain()
}

type user struct {
	username string
	domain   string
}

func (u user) GetEmail() string {
	return u.username + "@" + u.domain
}
func (u user) GetDomain() string {
    return u.domain
}

// IsAuthenticated determines if the user is authenticated. Authentication status is
// derived by querying the session cache.
func IsAuthenticated(api orchestrator.Orchestrator, rw http.ResponseWriter, _ *http.Request) bool {
	logger := api.Logger()
	logger.Info("se", "determining if user is authenticated or not")

	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
		return false
	}

	authenticationIDP, err := session.GetString("authenticationIdp")
	authenticated, err := session.GetString(authenticationIDP + ".authenticated")

	if err != nil {
		logger.Error(
			"se", fmt.Sprintf("unable to retrieve session value '%s.authenticated'", authenticationIDP),
			"error", err.Error(),
		)
        return false
	}
	if authenticated == "true" {
		logger.Info("se", fmt.Sprintf("user is authenticated with '%s'", authenticationIDP))
		email, err := session.GetString(authenticationIDP + ".email")
		if err != nil {
			logger.Error(
				"se", fmt.Sprintf("unable to retrieve session value '%s.email'", authenticationIDP),
				"error", err.Error(),
			)
            return false
		}
		session.SetString("GlobalLandingPage.email", email)
		err = session.Save()
		if err != nil {
			logger.Error(
				"se", fmt.Sprintf("unable to save session state: %v", authenticationIDP),
				"error", err.Error(),
			)
            return false
		}
		return true
	}
	logger.Info("not authenticated yet")
	return false
}

// Authenticate authenticates the user against the IDP that they select.
func Authenticate(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Info("se", "authenticating user")

	if req.Method == http.MethodGet {
		if strings.Contains(req.URL.Path, "style.css") {
			err := serve_css(api, rw)
			if nil != err {
				logger.Error("se", "Failed to serve CSS file", "error", err.Error())
				// page can still load if this error occurs
				http.Error(rw, "Internal Error, Please Contact System Admin.", http.StatusInternalServerError)
			}
			return
		}
		if strings.Contains(req.URL.Path, "images") {
			filename, _ := strings.CutPrefix(req.URL.Path, "/images/")
			err := serve_image(api, rw, filename)
			if nil != err {
				logger.Error("se", "failed to get image", "error", err.Error())
				// page can still load if this error occurs
				http.Error(rw, "Internal Error, Please Contact System Admin.", http.StatusInternalServerError)
			}
			return
		}
		if strings.Contains(req.URL.Path, "tabs") {
			filename, _ := strings.CutPrefix(req.URL.Path, "/tabs/")
			logger.Info("se", "Filename", "Name=", filename)
			err := serve_html(api, rw, filename, nil)
			if nil != err {
				logger.Error("se", "failed to get tab page", "error", err.Error())
				// page cannot load if this fails, show error page
				serve_error(api, rw, "Internal Error. Please Contact System Admin.", http.StatusInternalServerError)
			}
			return
		}

		// no path matched before...display index page
		err := serve_index(api, rw)
		if nil != err {
			logger.Error("se", "failed to get assets fs", "error", err.Error())
			serve_error(api, rw, "Internal Error. Please Contact System Admin.", http.StatusInternalServerError)
		}
		return
	}

	if req.Method != http.MethodPost {
		logger.Error("se", fmt.Sprintf("received unexpected request method '%s', expected POST", req.Method))
		http.Error(rw, http.StatusText(http.StatusBadRequest), http.StatusBadRequest)
		serve_error(api, rw, "", http.StatusBadRequest)
		return
	}

	// user, err := parse_form_request(req)
	// if nil != err {
	// 	logger.Error("se", "failed to parse form from request", "error", err.Error())
	// 	http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
	// 	return
	// }

	// Here you would determine the IDP based on the domain
	// For example, you could have a map or a switch statement
	// idpDomainMap maps email domains to IDP identifiers
	// idp, err := get_idp_provider(api, user)
	// if nil != err {
	// 	logger.Error("se", "unable to lookup idp", "error", err.Error())
	// 	http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
	// 	return
	// }

	// loginHintOption := idfabric.WithLoginHint(user.getEmail())
	// idp.Login(rw, req, loginHintOption)
	return
}

func get_idp_provider(api orchestrator.Orchestrator, user User) (idfabric.IdentityProvider, error) {
	// Here you would determine the IDP based on the domain
	// For example, you could have a map or a switch statement
	// idpDomainMap maps email domains to IDP identifiers
	var idpDomainMap = map[string]string{
		"M365x75558759.onmicrosoft.com": "EntraIDDemoTenant",
		//	"pingonetrial.com": "PingOneCIAMTrial",
		//	"oktatrial.com": "OktaIDPTest",
	}
	// Add more domain-to-IDP mappings here

	// Check if the domain exists in the idpDomainMap
	authenticationIDP, ok := idpDomainMap[user.Domain]
	session, err := api.Session()
    if nil != err {
        return nil, err
    }
	session.SetString("authenticationIdp", authenticationIDP)
	session.SetString("user_email", user.GetEmail())
	err = session.Save()
	if nil != err {
		return nil, err
	}

	if !ok {
		return nil, fmt.Errorf("no IDP found for domain")
	}

	idp, err := api.IdentityProvider(authenticationIDP)
	if nil != err {
		return nil, err
	}
	return idp, nil
}

func parse_form_request(req *http.Request) (User, error) {
	err := req.ParseForm()
	if nil != err {
		return User{}, err
	}
	email := req.Form.Get("username")
	split := strings.Split(email, "@")
	return User{split[0], split[1]}, nil
}

func serve_index(api orchestrator.Orchestrator, rw http.ResponseWriter) error {
	assetFS, err := api.ServiceExtensionAssets().FS()
	if nil != err {
		return err
	}
	indextmpl, err := template.ParseFS(assetFS, "index.html")
	err = indextmpl.Execute(rw, nil)
	return nil
}

func serve_image(api orchestrator.Orchestrator, w http.ResponseWriter, filename string) error {
	data, err := api.ServiceExtensionAssets().ReadFile(filename)
	if nil != err {
		return err
	}
	w.Header().Set("Content-Type", "image/png")
	w.Write(data)
	return nil
}

func serve_css(api orchestrator.Orchestrator, w http.ResponseWriter) error {
	data, err := api.ServiceExtensionAssets().ReadFile("style.css")
	if nil != err {
		return err
	}
	w.Header().Set("Content-Type", "text/css")
	w.Write(data)
	return nil
}

func serve_html(api orchestrator.Orchestrator, w http.ResponseWriter, filename string, data any) error {
	assetsFS, err := api.ServiceExtensionAssets().FS()
	tmpl, err := template.ParseFS(assetsFS, filename+".html")
	if nil != err {
		return err
	}
	w.Header().Set("Content-Type", "text/html")
	tmpl.Execute(w, data)
	return nil
}

func serve_error(api orchestrator.Orchestrator, w http.ResponseWriter, message string, code int) {
	assetFS, _ := api.ServiceExtensionAssets().FS()
	errtmpl, _ := template.ParseFS(assetFS, "error.html")
	http.Error(w, message, code)
	errtmpl.Execute(w, ErrorData{
		fmt.Sprintf("%s\n%s", message, http.StatusText(code)),
		code,
	})
	return
}
