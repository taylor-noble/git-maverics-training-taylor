package main

import (
	"fmt"
	"html/template"
	"net/http"
	"strings"

	ldap3 "github.com/go-ldap/ldap/v3"
	"github.com/strata-io/service-extension/idfabric"
	"github.com/strata-io/service-extension/log"
	"github.com/strata-io/service-extension/orchestrator"
)

// Structs and Enums
type ErrorState int

const (
	ErrorUnknown ErrorState = iota
	ErrorInvalidCitizenship
	ErrorNoIdPFound
	ErrorInvalidBemsid
	ErrorInvalidGeolocation
	Error1Kosmos
)

type ErrorData struct {
	Message     string
	Code        uint
	CodeMessage string
}

type User struct {
	Username string
	Domain   string
}

func (u User) GetEmail() string {
	return u.Username + "@" + u.Domain
}

type UserAccount struct {
	DN   string
	CN   string
	Mail string
}

// IsAuthenticated determines if the user is authenticated. Authentication status is
// derived by querying the session cache.
func IsAuthenticated(api orchestrator.Orchestrator, rw http.ResponseWriter, _ *http.Request) bool {
	logger := api.Logger()
	logger.Info("se", "determining if user is authenticated or not")

	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
		return false
	}

	authenticationIDP, err := session.GetString("authenticationIdp")
	authenticated, err := session.GetString(authenticationIDP + ".authenticated")

	if err != nil {
		logger.Error(
			"se", fmt.Sprintf("unable to retrieve session value '%s.authenticated'", authenticationIDP),
			"error", err.Error(),
		)
		return false
	}
	if authenticated == "true" {
		logger.Info("se", fmt.Sprintf("user is authenticated with '%s'", authenticationIDP))
		email, err := session.GetString(authenticationIDP + ".preferred_username")
		if err != nil {
			logger.Error(
				"se", fmt.Sprintf("unable to retrieve session value '%s.email'", authenticationIDP),
				"error", err.Error(),
			)
			return false
		}
		session.SetString("GlobalLandingPage_TaylorTest.email", email)
		logger.Info("se", fmt.Sprintf("user email: '%s'", email))
		err = session.Save()
		if err != nil {
			logger.Error(
				"se", fmt.Sprintf("unable to save session state: %v", authenticationIDP),
				"error", err.Error(),
			)
			return false
		}

		distinguished_name, err := getUserAccountFromAD(api, email, rw)
		if nil != err {
			logger.Error("se", "Error occurred during IDP value retrieval from LDAP", "error", err.Error())
			return false
		}
		logger.Info("se", fmt.Sprintf("User selected distinguished_name '%s'", distinguished_name))
		return true
	}
	logger.Info("not authenticated yet")
	return false
}

func getUserAccountFromAD(api orchestrator.Orchestrator, email string, rw http.ResponseWriter) (string, error) {
	logger := api.Logger()
	secretProvider, err := api.SecretProvider()
	router := api.Router()
	router.HandleFunc("/select", func(w http.ResponseWriter, r *http.Request) {
		logger.Info("se", "inside /select func")
		if r.Method == http.MethodPost {
			logger.Info("se", "inside /select func httppost")
			userDN := r.FormValue("user")
			fmt.Fprintf(w, "You selected user: %s", userDN)
		} else {
			logger.Error("se", "inside /select func error")
			http.Error(w, "Invalid request method", http.StatusMethodNotAllowed)
		}
	})
	if err != nil {
		logger.Error("se", "Unable to get secret provider", "error", err.Error())
		return "", err
	}

	ldapsURL := "ldap://ldap.stratademousers.com:389"
	l, err := ldap3.DialURL(ldapsURL)
	if err != nil {
		logger.Error("se", "Failed to connect to LDAPS server", "error", err.Error())
		return "", err
	}
	defer l.Close()

	serviceAccountUsername := secretProvider.GetString("serviceAccountUsername")
	serviceAccountPassword := secretProvider.GetString("serviceAccountPassword")
	if err := l.Bind(serviceAccountUsername, serviceAccountPassword); err != nil {
		logger.Error("se", "Failed to bind to LDAPS server", "error", err.Error())
		return "", err
	}

	searchRequest := ldap3.NewSearchRequest(
		"OU=users,DC=stratademousers,DC=com",
		ldap3.ScopeWholeSubtree, ldap3.NeverDerefAliases, 0, 0, false,
		fmt.Sprintf("(&(objectClass=inetOrgPerson)(mail=%s))", email),
		[]string{"mail", "cn", "homePhone", "objectClass"},
		nil,
	)

	searchResult, err := l.Search(searchRequest)
	if err != nil {
		logger.Error("se", "Failed to search LDAPS", "error", err.Error())
		return "", err
	}

	logger.Info("se", fmt.Sprintf("LDAP search result count:%d", len(searchResult.Entries)))
	logger.Info("se", fmt.Sprintf("LDAP search result:%+v", searchResult))
	if len(searchResult.Entries) == 0 {
		logger.Error("se", "No user found with email", "error", email)
		return "", fmt.Errorf("no user found with email: %s", email)
	}

	if len(searchResult.Entries) == 1 {
		session, err := api.Session()
		logger.Info("se", fmt.Sprintf("Search Results: %+v", searchResult.Entries[0]))
		objectClassSE := searchResult.Entries[0].GetAttributeValues("objectClass")
		otherMobileSE := searchResult.Entries[0].GetAttributeValues("homePhone")

		// Convert the slice to a single string, separated by commas (or any other separator you prefer)
		objectClassString := strings.Join(objectClassSE, ", ")
		otherMobileString := strings.Join(otherMobileSE, ", ")

		session.SetString("objectClassSE", objectClassString)
		session.SetString("otherMobileSE", otherMobileString)
		err = session.Save()
		if err != nil {
			logger.Error("se", fmt.Sprintf("unable to save session value"), "error", err.Error())
		}

		dnValueFromLDAP := searchResult.Entries[0].DN
		return dnValueFromLDAP, nil
	}

	// Handle multiple user accounts
	if len(searchResult.Entries) > 1 {
		logger.Info("se", "multiple accounts found:", len(searchResult.Entries))
		userAccounts := make([]UserAccount, 0)
		for _, entry := range searchResult.Entries {
			userAccounts = append(userAccounts, UserAccount{
				DN:   entry.DN,
				CN:   entry.GetAttributeValue("cn"),
				Mail: entry.GetAttributeValue("mail"),
			})
		}
		logger.Info("se", "multiple accounts list length: %d", len(userAccounts))

		// Render the selection page with a modal
		assetsFS, err := api.ServiceExtensionAssets().FS()
		if nil != err {
			return "", fmt.Errorf("Error getting assetsFS")
		}
		account_select_tmpl, err := template.ParseFS(assetsFS, "ad_account_select.html")
		if nil != err {
			return "", fmt.Errorf("Error getting account select template")
		}

		rw.Header().Set("Content-Type", "text/html")
		account_select_tmpl.Execute(rw, struct{ UserAccounts []UserAccount }{UserAccounts: userAccounts})
		return "", nil
	}

	return "", fmt.Errorf("some error")
}

// Authenticate authenticates the user against the IDP that they select.
func Authenticate(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	// DEBUG flag used for testing
	DEBUG := true

	logger := api.Logger()
	session, err := api.Session()
	if nil != err {
		logger.Error("se", "unable to get api session", "error", err.Error())
		serve_error(api, rw, ErrorUnknown)
		return
	}

	if req.Method == http.MethodGet {

		// DEBUG SECTION
		if DEBUG {

			// Error State map for testing
			errorStateMap := map[string]ErrorState{
				"unknown":            ErrorUnknown,
				"noprovider":         ErrorNoIdPFound,
				"1kosmos":            Error1Kosmos,
				"invalidgeo":         ErrorInvalidGeolocation,
				"invalidbemsid":      ErrorInvalidBemsid,
				"invalidcitizenship": ErrorInvalidCitizenship,
			}

			// go to /errors/<map_value> to see the given error type's page layout
			if strings.Contains(req.URL.Path, "errors") {
				errorStateString, _ := strings.CutPrefix(req.URL.Path, "/errors/")
				errorState, ok := errorStateMap[errorStateString]
				if !ok {
					serve_error(api, rw, ErrorUnknown)
				} else {
					serve_error(api, rw, errorState)
				}
				return
			}
		}
		// END DEBUG SECTION

		if strings.Contains(req.URL.Path, "htmx.min.js") {
			err := serve_js(api, rw)
			if nil != err {
				logger.Error("se", "Failed to serve JS file", "error", err.Error())
				// page can still load if this error occurs
				http.Error(rw, "Internal Error, Please Contact System Admin.", http.StatusInternalServerError)
			}
			return
		}

		if strings.Contains(req.URL.Path, "css") {
			filename, _ := strings.CutPrefix(req.URL.Path, "/css/")
			logger.Error("se", fmt.Sprintf("Loading CSS file: %s", filename))
			err := serve_css(api, rw, filename)
			if nil != err {
				logger.Error("se", "Failed to serve CSS file", "error", err.Error())
				// page can still load if this error occurs
				http.Error(rw, "Internal Error, Please Contact System Admin.", http.StatusInternalServerError)
			}
			return
		}
		if strings.Contains(req.URL.Path, "images") {
			filename, _ := strings.CutPrefix(req.URL.Path, "/images/")
			err := serve_image(api, rw, filename)
			if nil != err {
				logger.Error("se", "failed to get image", "error", err.Error())
				// page can still load if this error occurs
				http.Error(rw, "Internal Error, Please Contact System Admin.", http.StatusInternalServerError)
			}
			return
		}
		if strings.Contains(req.URL.Path, "tabs") {
			filename, _ := strings.CutPrefix(req.URL.Path, "/tabs/")
			logger.Info("se", "Filename", "Name=", filename)
			err := serve_html(api, rw, filename, nil)
			if nil != err {
				logger.Error("se", "failed to get tab page", "error", err.Error())
				// page cannot load if this fails, show error page
				serve_error(api, rw, ErrorUnknown)
			}
			return
		}

		// no path matched before...display index page
		// only serve index if not authenticated
		authentication_idp, err := session.GetString("authenticationIDP")
		if err != nil {
			logger.Error("se", "Unable to retrieve session data", "error", err.Error())
			return
		}
		authenticated, err := session.GetBool(authentication_idp + ".authenticated")
		if err != nil {
			logger.Error("se", "Unable to retrieve session data", "error", err.Error())
			return
		}

		if !authenticated {
			err := serve_index(api, rw)
			if nil != err {
				logger.Error("se", "failed to get assets fs", "error", err.Error())
				serve_error(api, rw, ErrorUnknown)
			}
		}
		return
	}

	if req.Method != http.MethodPost {
		logger.Error("se", fmt.Sprintf("received unexpected request method '%s', expected POST", req.Method))
		serve_error(api, rw, ErrorUnknown)
		return
	}

	// http.MethodPost from here to end of Authenticate
	logger.Info("se", "authenticating user")
	// get the User from the request
	user, err := parse_form_request(req)
	if nil != err {
		logger.Error("se", "failed to parse form from request", "error", err.Error())
		http.Error(rw, http.StatusText(http.StatusBadRequest), http.StatusBadRequest)
		serve_error(api, rw, ErrorUnknown)
		return
	}

	// Here you would determine the IDP based on the domain
	// For example, you could have a map or a switch statement
	// idpDomainMap maps email domains to IDP identifiers
	authenticationIDP, err := get_idp_provider(user, logger)
	if err != nil {
		logger.Error("se", "unable to lookup idp", "error", err.Error())
		serve_error(api, rw, ErrorNoIdPFound)
		return
	}

	logger.Info("se", fmt.Sprintf("User Email=%s", user.GetEmail()))
	err = session.SetString("authenticationIdp", authenticationIDP)
	if nil != err {
		logger.Error("se", "unable to save data to session", "error", err.Error())
		serve_error(api, rw, ErrorUnknown)
		return
	}

	err = session.SetString("user_email", user.GetEmail())
	if nil != err {
		logger.Error("se", "unable to save data to session", "error", err.Error())
		serve_error(api, rw, ErrorUnknown)
		return
	}

	logger.Info("se", fmt.Sprintf("Session=%+v", session))
	err = session.Save()
	if nil != err {
		logger.Error("se", "unable to save api session", "error", err.Error())
		serve_error(api, rw, ErrorUnknown)
		return
	}

	idp, err := api.IdentityProvider(authenticationIDP)
	logger.Info("se", fmt.Sprintf("Session=%+v", session))
	logger.Info("se", fmt.Sprintf("Session=%+v", session))
	if nil != err {
		logger.Error("se", "Unable to get IdentityProvider object", "error", err.Error())
		serve_error(api, rw, ErrorUnknown)
		return
	}

	loginHintOption := idfabric.WithLoginHint(user.GetEmail())
	idp.Login(rw, req, loginHintOption)
	return
}

func get_idp_provider(user User, logger log.Logger) (string, error) {
	// Here you would determine the IDP based on the domain
	// For example, you could have a map or a switch statement
	// idpDomainMap maps email domains to IDP identifiers
	idpDomainMap := map[string]string{
		"penguinztlive.onmicrosoft.com": "AzureTestApp-Taylor",
		"M365x75558759.onmicrosoft.com": "EntraIDDemoTenant",
		"test.example.com":              "ExampleTenant",
	}
	// Add more domain-to-IDP mappings here
	//	"pingonetrial.com": "PingOneCIAMTrial",
	//	"oktatrial.com": "OktaIDPTest",

	// Check if the domain exists in the idpDomainMap
	authenticationIDP, ok := idpDomainMap[user.Domain]

	logger.Info("se", "Inside get_idp_provider",
		fmt.Sprintf("user=%+v, idpDomainMap=%+v", user, idpDomainMap),
		fmt.Sprintf("authenticationIDP=%q, ok=%t", authenticationIDP, ok))

	if !ok {
		return "", fmt.Errorf("No IdP Provider")
	}

	return authenticationIDP, nil
}

func parse_form_request(req *http.Request) (User, error) {
	err := req.ParseForm()
	if nil != err {
		return User{"", ""}, err
	}
	email := req.Form.Get("username")
	split := strings.Split(email, "@")
	return User{split[0], split[1]}, nil
}

func serve_index(api orchestrator.Orchestrator, rw http.ResponseWriter) error {
	assetFS, err := api.ServiceExtensionAssets().FS()
	if nil != err {
		return err
	}
	indextmpl, err := template.ParseFS(assetFS, "index.html")
	err = indextmpl.Execute(rw, nil)
	return nil
}

func serve_js(api orchestrator.Orchestrator, w http.ResponseWriter) error {
	data, err := api.ServiceExtensionAssets().ReadFile("htmx.min.js")
	if nil != err {
		return err
	}
	w.Header().Set("Content-Type", "text/javascript")
	w.Write(data)
	return nil
}

func serve_image(api orchestrator.Orchestrator, w http.ResponseWriter, filename string) error {
	data, err := api.ServiceExtensionAssets().ReadFile(filename)
	filename_type_slice := strings.Split(filename, ".")
	filetype := filename_type_slice[len(filename_type_slice)-1]
	if nil != err {
		return err
	}
	w.Header().Set("Content-Type", "image/"+filetype)
	w.Write(data)
	return nil
}

func serve_css(api orchestrator.Orchestrator, w http.ResponseWriter, filename string) error {
	data, err := api.ServiceExtensionAssets().ReadFile(filename)
	if nil != err {
		return err
	}
	w.Header().Set("Content-Type", "text/css")
	w.Write(data)
	return nil
}

func serve_html(api orchestrator.Orchestrator, w http.ResponseWriter, filename string, data any) error {
	assetsFS, err := api.ServiceExtensionAssets().FS()
	tmpl, err := template.ParseFS(assetsFS, filename+".html")
	if nil != err {
		return err
	}
	w.Header().Set("Content-Type", "text/html")
	tmpl.Execute(w, data)
	return nil
}

func serve_error(api orchestrator.Orchestrator, w http.ResponseWriter, es ErrorState) error {
	assetFS, err := api.ServiceExtensionAssets().FS()
	if nil != err {
		return err
	}
	errtmpl, err := template.ParseFS(assetFS, "error.html")
	if nil != err {
		return err
	}
	errorData := generateErrorData(es)
	err = errtmpl.Execute(w, errorData)
	if nil != err {
		return err
	}
	return nil
}

func generateErrorData(es ErrorState) ErrorData {
	error_strings := map[ErrorState]string{
		ErrorUnknown:            "Looks like an error occured. Please contact helpdesk by phone or the link below for further assistance.",
		ErrorInvalidCitizenship: "Looks like you are accessing a resource only available to US citizens. If you think you have recieved this message in error please contact Helpdesk by phone or the link below.",
		ErrorNoIdPFound:         "Looks like we are unable to find the email domain you have entered. Please contact Helpdesk by phone or the link below.",
		ErrorInvalidBemsid:      "Looks like your BEMSID does not match what we have on file. Please contact Helpdesk by phone or the link below for assistance in logging in.",
		ErrorInvalidGeolocation: "Looks like you are trying to access a resource outside the USA. This resource is only available to users who currently reside on US soil.",
		Error1Kosmos:            "Error in Login from 1Kosmos. Please contact Helpdesk by phone or the link below for assistance logging in.",
	}

	error_codes := map[ErrorState]uint{
		ErrorUnknown:            http.StatusInternalServerError,
		ErrorInvalidCitizenship: http.StatusUnauthorized,
		ErrorNoIdPFound:         http.StatusBadRequest,
		ErrorInvalidBemsid:      http.StatusBadRequest,
		ErrorInvalidGeolocation: http.StatusUnauthorized,
		Error1Kosmos:            http.StatusBadRequest,
	}

	return ErrorData{
		error_strings[es],
		error_codes[es],
		http.StatusText(int(error_codes[es])),
	}
}
