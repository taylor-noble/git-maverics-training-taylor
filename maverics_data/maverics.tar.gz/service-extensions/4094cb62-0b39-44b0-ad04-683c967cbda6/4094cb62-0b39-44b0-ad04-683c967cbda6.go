package main

import (
	"fmt"
	"html/template"
	"net/http"
	"strings"

	"github.com/strata-io/service-extension/idfabric"
	"github.com/strata-io/service-extension/log"
	"github.com/strata-io/service-extension/orchestrator"
)

type RedirectData struct {
	AttemptedAuth bool
}

var redirectData *RedirectData

// IsAuthenticated determines if the user is authenticated. Authentication status is
// derived by querying the session cache.
func IsAuthenticated(api orchestrator.Orchestrator, w http.ResponseWriter, r *http.Request) bool {

	logger := api.Logger()
	logger.Info("se", "determining if user is authenticated or not")

	session, err := api.Session()

	logger.Info("se", fmt.Sprintf("Session: %+v", session))

	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		http.Error(w, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
		return false
	}

	authenticationIDP, err := session.GetString("authenticationIdp")
	if nil != err {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		http.Error(w, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
		return false
	}
	authenticated, err := session.GetBool(authenticationIDP + ".authenticated")
	if err != nil {
		logger.Error(
			"se", fmt.Sprintf("unable to retrieve session value '%s.authenticated'", authenticationIDP),
			"error", err.Error(),
		)
		return false
	}

	// Question: Does this function get called when a user directly tries to access auth.* subdomain?
	//    If not, then we could possibly use this session value to tell if a user has accessed the global landing page
	(*redirectData).AttemptedAuth = true
	if authenticated {
		logger.Info("se", fmt.Sprintf("user is authenticated with '%s'", authenticationIDP))
		email, err := session.GetString(authenticationIDP + ".email")
		if err != nil {
			logger.Error(
				"se", fmt.Sprintf("unable to retrieve session value '%s.email'", authenticationIDP),
				"error", err.Error(),
			)
			return false
		}
		session.SetString("GlobalLandingPage.email", email)
		err = session.Save()
		if err != nil {
			logger.Error(
				"se", fmt.Sprintf("unable to save session state: %v", authenticationIDP),
				"error", err.Error(),
			)
			return false
		}
		return true
	}

	logger.Info("not authenticated yet")
	return false
}

// Authenticate authenticates the user against the IDP that they select.
func Authenticate(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {

	logger := api.Logger()

	// router to handle error page rendering
	router := api.Router()

	// assetFS used to get files for serving
	assetsFS, err := api.ServiceExtensionAssets().FS()
	if nil != err {
		http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
		return
	}

	// Session to store/retrieve data between redirects
	session, err := api.Session()
	logger.Info("se", fmt.Sprintf("Session: %+v", session))
	if nil != err {
		http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
		return
	}

	//  Maps each error type to a URL path
	//  Make sure to add error text and status code in generateErrorData() function below
	auth_subdomain_errors := "https://auth.dummyboeing.com/errors"
	errorStateMap := map[string]ErrorState{
		"unknown":            ErrorUnknown,
		"noprovider":         ErrorNoIdPFound,
		"1kosmos":            Error1Kosmos,
		"invalidgeo":         ErrorInvalidGeolocation,
		"invalidbemsid":      ErrorInvalidBemsid,
		"invalidcitizenship": ErrorInvalidCitizenship,
		"proofingError":      ErrorMissingProofing,
		"errorLongTest":      ErrorLongTest,
	}

	// The following two router.HandleFunc() functions are used to
	//  render the error pages from auth.* subdomain and serve the style.css file for the error page.
	router.HandleFunc("/style.css", func(w http.ResponseWriter, r *http.Request) {

		if nil != err {
			http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
			return
		}
		if !(*redirectData).AttemptedAuth {
			// serving this file is only allowed if the user has already been authenticated.
			// user will authenticate when they are served /errors/ pages
			return
		}

		if req.Method == http.MethodGet {

			cssFile, err := assetsFS.Open("style.css")
			if nil != err {
				logger.Error("se", "Failed to serve CSS file", "error", err.Error())
				// page can still load if this error occurs
				http.Error(rw, "Internal Error, Please Contact System Admin.", http.StatusInternalServerError)
			}
			defer cssFile.Close()

			var data []byte
			_, err = cssFile.Read(data)
			if nil != err {
				logger.Error("se", "Failed to read CSS file", "error", err.Error())
				// page can still load if this error occurs
				http.Error(rw, "Internal Error, Please Contact System Admin.", http.StatusInternalServerError)
			}

			rw.Header().Set("Content-Type", "text/css")
			rw.Write(data)
			return
		}
	})

	router.HandleFunc("/errors/", func(w http.ResponseWriter, r *http.Request) {
		logger.Info("se", "Has User Attempted Authentication?", (*redirectData).AttemptedAuth)
		if nil != err {
			http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
			return
		}
		if (*redirectData).AttemptedAuth {
			// serving this file is only allowed if the user has tryed to authenticate.
			return
		}

		error_type, _ := strings.CutPrefix(r.URL.Path, "/errors/")
		es, ok := errorStateMap[error_type]
		if !ok {
			es = ErrorUnknown
		}

		error_data := generateErrorData(es)
		logger.Info("se", "Error Data: ", fmt.Sprintf("%+v", error_data))
		error_template, err := template.ParseFS(assetsFS, "error.html")
		if nil != err {
			http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
		}

		error_template.Execute(w, error_data)
	})

	// The folliwng string.Contains() checks on req.URL.Path are served from proxy.* subdomain

	if strings.Contains(req.URL.Path, "/htmx.min.js") {
		if req.Method == http.MethodGet {
			data, err := api.ServiceExtensionAssets().ReadFile("htmx.min.js")
			if nil != err {
				logger.Error("se", "Failed to serve JS file", "error", err.Error())
				// page can still load if this error occurs
				http.Error(rw, "Internal Error, Please Contact System Admin.", http.StatusInternalServerError)
			}
			rw.Header().Set("Content-Type", "text/javascript")
			rw.Write(data)
			return
		}
	}

	if strings.Contains(req.URL.Path, "/style.css") {
		if req.Method == http.MethodGet {
			data, err := api.ServiceExtensionAssets().ReadFile("style.css")
			if nil != err {
				logger.Error("se", "Failed to serve CSS file", "error", err.Error())
				// page can still load if this error occurs
				http.Error(rw, "Internal Error, Please Contact System Admin.", http.StatusInternalServerError)
			}
			rw.Header().Set("Content-Type", "text/css")
			rw.Write(data)
			return
		}
	}

	if strings.Contains(req.URL.Path, "/images/") {
		if req.Method == http.MethodGet {
			filename, _ := strings.CutPrefix(req.URL.Path, "/images/")
			data, err := api.ServiceExtensionAssets().ReadFile(filename)
			filename_type_slice := strings.Split(filename, ".")
			filetype := filename_type_slice[len(filename_type_slice)-1]
			if nil != err {
				logger.Error("se", "failed to get image", "error", err.Error())
				// page can still load if this error occurs
				http.Error(rw, "Internal Error, Please Contact System Admin.", http.StatusInternalServerError)
			}
			rw.Header().Set("Content-Type", "image/"+filetype)
			rw.Write(data)
			return
		}

	}

	if strings.Contains(req.URL.Path, "/tabs/") {
		if req.Method == http.MethodGet {
			filename, _ := strings.CutPrefix(req.URL.Path, "/tabs/")
			logger.Info("se", "Filename", "Name=", filename)
			tmpl, err := template.ParseFS(assetsFS, filename+".html")
			if nil != err {
				logger.Error("se", "failed to get tab page", "error", err.Error())
				// page cannot load if this fails, show error page
				http.Redirect(rw, req, auth_subdomain_errors+"/unknown", http.StatusSeeOther)
			}
			rw.Header().Set("Content-Type", "text/html")
			tmpl.Execute(rw, nil)
			return
		}
	}

	// Serves the index file from proxy.* subdomain
	if req.Method == http.MethodGet {
		indextmpl, _ := template.ParseFS(assetsFS, "index.html")
		indextmpl.Execute(rw, nil)
		return
	}

	// process Post Req from proxy.* subdomain
	// Here if any errors occur, must use http.Redirect() to the corresponding
	//     error page on auth.* subdomain
	if req.Method == http.MethodPost {
		logger.Info("se", "authenticating user")

		// get the User from the request
		user, err := parse_form_request(req)

		if nil != err {
			logger.Error("se", "failed to parse form from request", "error", err.Error())
			http.Error(rw, http.StatusText(http.StatusBadRequest), http.StatusBadRequest)
			http.Redirect(rw, req, auth_subdomain_errors+"/unknown", http.StatusSeeOther)
			return
		}

		// Here you would determine the IDP based on the domain
		// For example, you could have a map or a switch statement
		// idpDomainMap maps email domains to IDP identifiers
		logger.Info("se", fmt.Sprintf("Before getting IDP, User=%+v", user))
		authenticationIDP, err := get_idp_provider(user, logger)
		if err != nil {
			logger.Error("se", "unable to lookup idp", "error", err.Error())
			http.Redirect(rw, req, auth_subdomain_errors+"/noprovider", http.StatusSeeOther)
			return
		}

		logger.Info("se", fmt.Sprintf("User Email=%s", user.GetEmail()))
		session, err := api.Session()
		if nil != err {
			logger.Error("se", "unable to get api session", "error", err.Error())
			http.Redirect(rw, req, auth_subdomain_errors+"/unknown", http.StatusSeeOther)
			return
		}
		err = session.SetString("authenticationIdp", authenticationIDP)
		if nil != err {
			logger.Error("se", "unable to save data to session", "error", err.Error())
			http.Redirect(rw, req, auth_subdomain_errors+"/unknown", http.StatusSeeOther)
			return
		}

		err = session.SetString("user_email", user.GetEmail())
		if nil != err {
			logger.Error("se", "unable to save data to session", "error", err.Error())
			http.Redirect(rw, req, auth_subdomain_errors+"/unknown", http.StatusSeeOther)
			return
		}

		err = session.Save()
		if nil != err {
			logger.Error("se", "unable to save api session", "error", err.Error())
			http.Redirect(rw, req, auth_subdomain_errors+"/unknown", http.StatusSeeOther)
			return
		}

		idp, err := api.IdentityProvider(authenticationIDP)
		if nil != err {
			logger.Error("se", "Unable to get IdentityProvider object", "error", err.Error())
			http.Redirect(rw, req, auth_subdomain_errors+"/unknown", http.StatusSeeOther)
			return
		}

		loginHintOption := idfabric.WithLoginHint(user.GetEmail())
		idp.Login(rw, req, loginHintOption)
		return
	}

	logger.Error("se", fmt.Sprintf("received unexpected request method '%s', expected POST", req.Method))
	http.Redirect(rw, req, auth_subdomain_errors+"/unknown", http.StatusMethodNotAllowed)
}

// Helper Functions and Structs

type User struct {
	Username string
	Domain   string
}

func (u User) GetEmail() string {
	return u.Username + "@" + u.Domain
}

func get_idp_provider(user User, logger log.Logger) (string, error) {
	// Here you would determine the IDP based on the domain
	// For example, you could have a map or a switch statement
	// idpDomainMap maps email domains to IDP identifiers
	idpDomainMap := map[string]string{
		"penguinztlive.onmicrosoft.com": "AzureTestApp-Taylor",
		"M365x75558759.onmicrosoft.com": "EntraIDDemoTenant",
		"test.example.com":              "ExampleTenant",
	}
	// Add more domain-to-IDP mappings here
	//	"pingonetrial.com": "PingOneCIAMTrial",
	//	"oktatrial.com": "OktaIDPTest",

	// Check if the domain exists in the idpDomainMap
	authenticationIDP, ok := idpDomainMap[user.Domain]

	logger.Info("se", "Inside get_idp_provider",
		fmt.Sprintf("user=%+v, idpDomainMap=%+v", user, idpDomainMap),
		fmt.Sprintf("authenticationIDP=%q, ok=%t", authenticationIDP, ok))

	if !ok {
		return "", fmt.Errorf("No IdP Provider")
	}

	return authenticationIDP, nil
}

func parse_form_request(req *http.Request) (User, error) {
	err := req.ParseForm()
	if nil != err {
		return User{"", ""}, err
	}
	email := req.Form.Get("username")
	split := strings.Split(email, "@")
	return User{split[0], split[1]}, nil
}

// Error State Related Code

type ErrorState int

const (
	ErrorUnknown ErrorState = iota
	ErrorInvalidCitizenship
	ErrorNoIdPFound
	ErrorInvalidBemsid
	ErrorInvalidGeolocation
	Error1Kosmos
	ErrorMissingProofing
	ErrorLongTest
)

type ErrorData struct {
	Message     string
	Code        uint
	CodeMessage string
	Redirect    bool
}

func generateErrorData(es ErrorState) ErrorData {
	error_strings := map[ErrorState]string{
		ErrorUnknown:            "Looks like an error occured. Please contact helpdesk by phone or the link below for further assistance.",
		ErrorInvalidCitizenship: "Looks like you are accessing a resource only available to US citizens. If you think you have recieved this message in error please contact Helpdesk by phone or the link below.",
		ErrorNoIdPFound:         "Looks like we are unable to find the email domain you have entered. Please contact Helpdesk by phone or the link below.",
		ErrorInvalidBemsid:      "Looks like your BEMSID does not match what we have on file. Please contact Helpdesk by phone or the link below for assistance in logging in.",
		ErrorInvalidGeolocation: "Looks like you are trying to access a resource outside the USA. This resource is only available to users who currently reside on US soil.",
		Error1Kosmos:            "Error in Login from 1Kosmos. Please contact Helpdesk by phone or the link below for assistance logging in.",
		ErrorMissingProofing:    "Looks like you need to provide more information to access this resource. You will be re-directed to next step in 5 seconds.",
		ErrorLongTest:           "Lorem ipsum dolor sit amet consectetur adipiscing elit. Quisque faucibus ex sapien vitae pellentesque sem placerat. In id cursus mi pretium tellus duis convallis. Tempus leo eu aenean sed diam urna tempor. Pulvinar vivamus fringilla lacus nec metus bibendum egestas. Iaculis massa nisl malesuada lacinia integer nunc posuere. Ut hendrerit semper vel class aptent taciti sociosqu. Ad litora torquent per conubia nostra inceptos himenaeos. Lorem ipsum dolor sit amet consectetur adipiscing elit. Quisque faucibus ex sapien vitae pellentesque sem placerat. In id cursus mi pretium tellus duis convallis. Tempus leo eu aenean sed diam urna tempor.",
	}

	error_codes := map[ErrorState]uint{
		ErrorUnknown:            http.StatusInternalServerError,
		ErrorInvalidCitizenship: http.StatusUnauthorized,
		ErrorNoIdPFound:         http.StatusBadRequest,
		ErrorInvalidBemsid:      http.StatusBadRequest,
		ErrorInvalidGeolocation: http.StatusUnauthorized,
		Error1Kosmos:            http.StatusBadRequest,
		ErrorMissingProofing:    http.StatusSeeOther,
		ErrorLongTest:           http.StatusRequestURITooLong,
	}

	return ErrorData{
		error_strings[es],
		error_codes[es],
		http.StatusText(int(error_codes[es])),
		// Missing Proofing Error Type has a redirect
		// link curently hardcoded within error.html script tag
		es == ErrorMissingProofing,
	}
}
